﻿namespace BookShop.DataProcessor.ImportDto
{
    public class ImportBooksDto
    {

        public int? Id { get; set; }
    }
}
