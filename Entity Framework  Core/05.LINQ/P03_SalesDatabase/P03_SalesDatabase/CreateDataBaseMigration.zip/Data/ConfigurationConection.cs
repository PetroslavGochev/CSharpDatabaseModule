﻿namespace P03_SalesDatabase.Data
{
    internal static class ConfigurationConection
    {
        internal static string ConnectionString = @"Server=.;Database=SalesDatabase;Integrated Security=true";
    }
}
