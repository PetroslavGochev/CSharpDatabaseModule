﻿namespace P01_HospitalDatabase.Data
{
    internal static class ConfigurationConection
    {
        internal static string Conection = @"Server=.;Database=HospitalDatabase;Integrated Security=true";
    }
}
